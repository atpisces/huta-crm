<script>

  initDataTable('.table-table_purorder_wg', admin_url+'purchase/dashboard_po_table');

</script> 