<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
	<div class="content">
		<div class="row">
			<?php $this->load->view('quotations/list_template'); ?>
		</div>
	</div>
</div>

<?php init_tail(); ?>

</body>
</html>
