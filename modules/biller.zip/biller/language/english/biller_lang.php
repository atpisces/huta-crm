<?php 
#billers
$lang['biller']                                   = 'biller';
$lang['billers_title']                            = 'biller Logs';
$lang['biller_logs']                              = 'biller Logs';
$lang['new_biller_log']                           = 'Add biller Log';
$lang['biller_lowercase']                         = 'biller log';
$lang['completed_biller']                         = 'Completed biller';
$lang['current_biller']                           = 'Current biller';
$lang['biller_direction']                         = 'biller Direction';
$lang['purpose']                                    = 'Purpose';
$lang['yes']                                        = 'Yes';
$lang['no']                                         = 'No';
$lang['notes']                                      = 'Notes';
$lang['followup_time']                              = 'Follow-up Time';
$lang['followup_notes']                             = 'Follow-up Notes';
$lang['biller_start_time']                        = 'biller Start Time';
$lang['biller_end_time']                          = 'biller End Time';
$lang['biller_duration']                          = 'biller Duration';
$lang['biller_owner']                             = 'biller Owner';
$lang['inbound']                                    = 'Inbound';
$lang['outbound']                                   = 'Outbound';
$lang['followp_required']                           = 'Follow-up Required';
$lang['make_followup_biller']                     = 'Make Followup biller';
$lang['end_biller']                               = 'End biller';
$lang['select_staff']                               = 'biller For';
$lang['import_staff']                               = 'Import Staff';
$lang['item_image']                                 = 'Item image';
$lang['biller_for']                               = 'biller For ';
$lang['purpose_of_biller']                        = 'Purpose of biller ';
$lang['biller_no_purpose']                        = 'No purpose for this biller';
$lang['biller_no_summary']                        = 'No summary for this biller';
$lang['biller_info']                              = 'biller Info';
$lang['biller_created_at']                        = 'Created at ';
$lang['clone']                                      = 'Clone ';
$lang['failed_to_copy_biller']                    = 'Failed to copy biller';
$lang['biller_copied_successfully']               = 'biller log copied successfully.';
$lang['customer'] 					                = 'Customer';
$lang['done'] 					                    = 'Done';
$lang['invoice_no'] 					            = 'Invoice No';
$lang['record_as_issue'] 					        = 'Record As Issue';
$lang['clients_list_biller']                      = 'biller';
$lang['biller_group_edit_heading']                = 'Edit biller Group';
$lang['biller_group_add_heading']                 = 'Add New biller Group';
$lang['biller_inactive_message']                  = 'This is inactive biller profile and some features may be disabled';
$lang['biller_admin_login_as_client_message']     = 'Hello %s. You are added as admin to this biller.';
$lang['login_as_biller']                          = 'Login as biller';
$lang['biller_from_lead']                         = 'biller from %s';
$lang['new_biller_group']                         = 'New biller Group';
$lang['new_biller']                               = 'New biller';
$lang['import_billers']                           = 'Import billers';
$lang['billers_assigned_to_me']                   = 'billers assigned to me';
$lang['active_billers']                           = 'Active billers';
$lang['inactive_active_biller']                   = 'Inactive billers';
$lang['bulk_action_billers_groups_warning']       = 'If you do not select any group all groups assigned to the selected billers will be removed.';
$lang['biller_files_info_message']                = 'Files from projects and tasks linked to the biller are not shown on this table.';
$lang['biller_attachments_show_in_customers_area'] = 'Show to billers area';
$lang['biller_attachments_show_notice']            = 'Only files uploaded from biller profile have ability to show/hide in customers area.';
$lang['biller_admins']                             = 'biller Admins';
$lang['biller_currency_change_notice']             = 'If the biller use other currency then the base currency make sure you select the appropriate currency for this biller. Changing the currency is not possible after transactions are recorded.';
$lang['biller_billing_same_as_profile']            = 'Same as biller Info';
$lang['biller_shipping_address_notice']            = 'Do not fill shipping address information if you won\'t use shipping address on biller invoices';
$lang['biller_statement_for']                      = 'biller Statement For %s';
$lang['biller_lowercase']                          = 'Biller';
$lang['biller_delete_transactions_warning']        = 'This biller has transactions, %s, you must delete the transactions or move to another biller in order to perform this action.';
$lang['biller_group']                              = 'Biller Group';
$lang['biller_group_lowercase']                    = 'Biller group';
$lang['total_billers_deleted']                     = 'Total billers deleted: %s';
$lang['biller_profile_details']                    = 'Biller Details';
$lang['biller_summary']							 = 'Biller summary';
# Clients
// $lang['is_biller']                    		 = 'Is biller';
// $lang['clients']                                 = 'biller';
// $lang['vendor']                                  = 'Vendor';
$lang['biller']                                  = 'biller';
$lang['billers']                                  = 'billers';
// $lang['biller']                                = 'biller';
// $lang['select_client']                           = 'Select biller';
// $lang['select_biller']                         = 'Select biller';
// $lang['new_client']                              = 'New biller';
// $lang['client_lowercase']                        = 'biller';

// $lang['client_company']                          = 'biller Company';

// $lang['login_as_client']                         = 'Login as biller';

// $lang['contract_client_string']   = 'biller';

// $lang['contract_list_client']     = 'biller';


// $lang['department_hide_from_client'] = 'Hide from biller?';


// $lang['email_template_clients_fields_heading']  = 'biller';


// $lang['clients_list_company'] = 'biller';


// $lang['import_customers']            = 'Import biller';
$lang['preffered_biller']				="Preferred biller";
$lang['not_preffered_biller']				="Not Preferred biller";
$lang['product_and_service']				="Products and services";
$lang['billers_summary_total']				="Total billers";