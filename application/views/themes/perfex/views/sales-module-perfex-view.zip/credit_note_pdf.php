<?php

defined('BASEPATH') or exit('No direct script access allowed');

$dimensions = $pdf->getPageDimensions();


$info_center_column = '<div style="width:100%; float:left; text-align:center;">
<h4 style="font-weight:bold; margin-left:50%;">رقم مذكرة الائتمان<br> ' . _l('credit_note_pdf_heading') . '</h4>
</div>';

$info_left_column = '<div style="float:left; width:60%;">
    <div style="float:left; width:75%; text-align:center;">
        <table class="table" border="1" cellpadding="0" cellspacing="0" width="100%">
            <tr>
                <th>Credit Note Number:</th>
                <td>' . $credit_note_number . '</td>
                <td>' . $credit_note_number . '</td>
                <th style="text-align:right;">رقم الفاتورة</th>
            </tr>
        </table>
        <table class="table" border="1" cellpadding="0" cellspacing="0" width="100%">
            <tr>
                <th>Invoice Ref. Number:</th>
                <td>' . $credit_note->reference_no . '</td>
                <td>' . $credit_note->reference_no . '</td>
                <th style="text-align:right;">رقم مرجع الفاتورة </th>
            </tr>
        </table>
        <table class="table" border="1" cellpadding="0" cellspacing="0" width="100%">
            <tr>
                <th>Credit Note Date:</th>
                <td>' . _d($credit_note->date) . '</td>
                <td>' . _d($credit_note->date) . '</td>
                <th style="text-align:right;">تاريخ إصدار الفاتورة</th>
            </tr>
            
        </table>
    </div>
</div>';

$file =  "assets/images/".$invoice->hash.".png";

$info_right_column = '<div style="float:left; width:60%;">
                        <img src="'.site_url($file).'" style="width: 200px;">
                     </div>';

// Add logo
$info_left_column .= pdf_logo_url();
// Write top left logo and right column info/text
pdf_multi_row($info_center_column,"", $pdf, ($dimensions['wk']) - $dimensions['lm']);
pdf_multi_row($info_left_column,$info_right_column, $pdf, ($dimensions['wk'] / 1.5) - $dimensions['lm']);

$pdf->ln(5);

//$organization_info = '<div style="color:#424242;">';

$organization_info = '<table class="table table-bordered" border="1" cellpadding="0" cellspacing="0" width="100%">
   <tr>
      <th>Name</th>
      <td>'.get_option('invoice_company_name').'</td>
      <td>'.get_option('invoice_company_name').'</td>
      <th style="text-align:right;">اسم</th>
   </tr>
   <tr>
      <th>Building No.</th>
      <td></td>
      <td></td>
      <th style="text-align:right;">رقم المبنى</th>
   </tr>
   <tr>
      <th>Street Name</th>
      <td>'.get_option('invoice_company_address').'</td>
      <td>'.get_option('invoice_company_address').'</td>
      <th style="text-align:right;">اسم الشارع</th>
   </tr>
   <tr>
      <th>District</th>
      <td></td>
      <td></td>
      <th style="text-align:right;">يصرف</th>
   </tr>
   <tr>
      <th>City</th>
      <td>'.get_option('invoice_company_city').'</td>
      <td>'.get_option('invoice_company_city').'</td>
      <th style="text-align:right;">مدينة</th>
   </tr>
   <tr>
      <th>Country</th>
      <td>'.get_option('invoice_company_country_code').'</td>
      <td>'.get_option('invoice_company_country_code').'</td>
      <th style="text-align:right;">دولة</th>
   </tr>
   <tr>
      <th>Postal Code</th>
      <td>'.get_option('invoice_company_postal_code').'</td>
      <td>'.get_option('invoice_company_postal_code').'</td>
      <th style="text-align:right;">رمز بريدي</th>
   </tr>
   <tr>
      <th>Additional Number</th>
      <td>'.get_option('invoice_company_phonenumber').'</td>
      <td>'.get_option('invoice_company_phonenumber').'</td>
      <th style="text-align:right;">رقم إضافي</th>
   </tr>
   <tr>
      <th>Vat Number</th>
      <td>'.get_option('company_vat').'</td>
      <td>'.get_option('company_vat').'</td>
      <th style="text-align:right;">ظريبه الشراء</th>
   </tr>
   <tr>
      <th>Other Sale ID</th>
      <td></td>
      <td></td>
      <th style="text-align:right;">معرف بيع آخر</th>
   </tr>
</table>';

$buyer_info = '<table class="table table-bordered" border="1" cellpadding="0" cellspacing="0" width="100%">
      <tr>
         <th>Name</th>
         <td>'.$invoice->client->company.'</td>
         <td>'.$invoice->client->company.'</td>
         <th style="text-align:right;">اسم</th>
      </tr>
      <tr>
         <th>Building No.</th>
         <td></td>
         <td></td>
         <th style="text-align:right;">رقم المبنى</th>
      </tr>
      <tr>
         <th>Street Name</th>
         <td>'.$invoice->client->address.'</td>
         <td>'.$invoice->client->address.'</td>
         <th style="text-align:right;">اسم الشارع</th>
      </tr>
      <tr>
         <th>District</th>
         <td></td>
         <td></td>
         <th style="text-align:right;">يصرف</th>
      </tr>
      <tr>
         <th>City</th>
         <td>'.$invoice->client->city.'</td>
         <td>'.$invoice->client->city.'</td>
         <th style="text-align:right;">مدينة</th>
      </tr>
      <tr>
         <th>Country</th>
         <td>'.$invoice->client->country.'</td>
         <td>'.$invoice->client->country.'</td>
         <th style="text-align:right;">دولة</th>
      </tr>
      <tr>
         <th>Postal Code</th>
         <td>'.$invoice->client->zip.'</td>
         <td>'.$invoice->client->zip.'</td>
         <th style="text-align:right;">رمز بريدي</th>
      </tr>
      <tr>
         <th>Additional Number</th>
         <td>'.$invoice->client->phonenumber.'</td>
         <td>'.$invoice->client->phonenumber.'</td>
         <th style="text-align:right;">رقم إضافي</th>
      </tr>
      <tr>
         <th>Vat Number</th>
         <td>'.$invoice->client->vat.'</td>
         <td>'.$invoice->client->vat.'</td>
         <th style="text-align:right;">ظريبه الشراء</th>
      </tr>
      <tr>
         <th>Other Buyer ID</th>
         <td></td>
         <td></td>
         <th style="text-align:right;">معرف المشتري الآخر</th>
      </tr>

</table>';

pdf_multi_row($organization_info, $buyer_info, $pdf, ($dimensions['wk'] / 2) - $dimensions['lm']);

$pdf->ln(5);

$items = get_items_table_data($credit_note, 'credit_note');

foreach ($credit_note->items as $row) {
   $item = '
<tr>
   <td>'.$row["description"].'</td>
   <td align="center">'.app_format_money($row["rate"], $credit_note->currency_name).'</td>
   <td align="center">'.app_format_money($row["qty"], $credit_note->currency_name).'</td>
   <td align="center">'.$row["qty"].'</td>
   <td align="center">'.app_format_money($row["tax"], $credit_note->currency_name).'</td>
   <td align="center">'.app_format_money($row["discount"], $credit_note->currency_name).'</td>
   <td align="center">'.app_format_money($row["tax"], $credit_note->currency_name).'</td>
   <td align="center">'.app_format_money($row["rate"] * $row["qty"], $credit_note->currency_name).'</td>
</tr>';
}


$invoice_info = ' <table class="table table-bordered" border="1" cellpadding="0" cellspacing="0" width="95%">
                 
<thead>
   <tr style="background-color:#415164; color:#fff; border:1px solid #fff;">
      <th colspan="4">
         Line Items
      </th>
      <th colspan="4" style="text-align:right;">
      البنود
      </th>
   </tr>
   <tr style="background-color:#415164; color:#fff; border:1px solid #fff;">
      <th>
         Nature of Goods or <br>Services<br>
         طبيعة السلع أو الخدمات
      </th>
      <th>
         Unit Price
         سعر الوحدة
      </th>
      <th>
         Quantity
         كمية
      </th>
      <th>
         Taxable Amount
         المبلغ الخاضع للضريبة
      </th>
      <th>
         Discount
         خصم
      </th>
      <th>
         Tax Rate
         معدل الضريبة
      </th>
      <th>
         Tax Amount
         قيمة الضريبة
      </th>
      <th>
         Item Subtotal<br>(Including VAT)<br>
         المجموع الفرعي للبند <br> (متضمنًا ضريبة القيمة المضافة)
      </th>
   </tr>
</thead>
<tbody>
'.$item.'             
</tbody>
</table>';
pdf_multi_row($invoice_info, "", $pdf, ($dimensions['wk'] ) - $dimensions['lm']);

$pdf->ln(5);
$invoice_total = ' <table class="table table-bordered" border="1" cellpadding="0" cellspacing="0" width="95%">                 
<thead>
   <tr style="background-color:#415164; color:#fff; border:1px solid #fff;">
      <th colspan="2">
         Total Amounts:
      </th>
      <th colspan="2" style="text-align:right;">
      المبالغ الإجمالية
      </th>
   </tr>
</thead>
<tbody>
   <tr>
      <th>
      </th>
      <th>
         Sub Total
      </th>
      <td align="right">
      المجموع الفرعي	
      </td>
      <td>
      '.app_format_money($credit_note->subtotal, $credit_note->currency_name).'
      </td>
   </tr>
   <tr>
      <th>
      </th>
      <th>
      Total
      </th>
      <td align="right">
      المجموع
      </td>
      <td>
      '.app_format_money($credit_note->total, $credit_note->currency_name).'
      </td>
   </tr>
   <tr>
      <th>
      </th>
      <th>
      Total Paid	
      </th>
      <td align="right">
      مجموع المبالغ المدفوعة	
      </td>
      <td>
      '. "-" . app_format_money(sum_from_table(db_prefix() . 'creditnote_refunds', array('field' => 'amount', 'where' => array('credit_note_id' => $credit_note->id))), $credit_note->currency_name).'
      </td>
   </tr>
   <tr>
      <th>
      </th>
      <th>
      Amount Due	
      </th>
      <td align="right">
      المبلغ المستحق	
      </td>
      <td>
      '.app_format_money($credit_note->total_left_to_pay, $credit_note->currency_name).'
      </td>
   </tr>
</tbody>
</table>';
pdf_multi_row($invoice_total, "", $pdf, ($dimensions['wk'] ) - $dimensions['lm']);

